let div = document.createElement('div');
let ol = document.createElement('ol');
let li = document.createElement('li');
let textNode = document.createTextNode('Bon-bon mange un bon');
let li1 = document.createElement('li');
let textNode1 = document.createTextNode('Panda wa pan de pan o ageru');
let li2 = document.createElement('li');
let textNode2 = document.createTextNode('Das Mädchen');
document.body.append(div);
div.classList.add('jokes');
let jokes = document.querySelector('.jokes');
jokes.style.margin = "50px";
jokes.style.backgroundColor = "#FFEFDF";
div.append(ol);
ol.append(li);
li.append(textNode);
ol.append(li1);
li1.append(textNode1);
ol.append(li2);
li2.append(textNode2);

function multi(){
    let inp1 = document.getElementById('inp1').value,
    inp2 = document.getElementById('inp2').value;
    let outp = document.getElementById('outp')
    console.log(inp1*inp2);
    result = inp1 * inp2;
    document.getElementById("outp").value = result;
}
